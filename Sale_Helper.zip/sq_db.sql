CREATE TABLE IF NOT EXISTS project_comments (
id integer PRIMARY KEY AUTOINCREMENT,
leads_email TEXT,
warehouse_ID TEXT,
comments TEXT
);